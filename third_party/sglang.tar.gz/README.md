# sglang dependency source snapshot

Runtime and build sources from revision a9b81e4caa240c8cad4f7dc1889ff4852a0fca5b. See the parent project third_party/manifest.json for file hashes and local modifications. Upstream project: https://github.com/sgl-project/sglang. This URL identifies upstream, not the exact fork.

## Third-party attribution for anonymous review

Names of upstream authors, companies and institutions, contact addresses,
repository namespaces, public model/dataset identifiers and example URLs in
third-party source and license notices identify their original sources. They
are retained for attribution and interoperability, not as a declaration of
this submission's authorship or affiliation. Such attribution alone does not
disclose submission authors. Original licenses and copyright notices remain
unchanged. Local adaptations are recorded separately; an unverified local
remark is not assigned to upstream merely because it is in a dependency.
