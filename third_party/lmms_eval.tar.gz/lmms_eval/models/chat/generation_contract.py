"""Small, dependency-free helpers for OpenAI-compatible generation."""

from __future__ import annotations

import ast
from typing import Any, Sequence


QWEN25_OCR_TASKS = frozenset(
    {
        "gam_hiertext",
        "gam_icdar2015",
        "gam_totaltext",
        "gam_sroie",
        "gam_hiertext_Boxonly",
        "gam_icdar2015_Boxonly",
        "gam_totaltext_Boxonly",
        "gam_sroie_Boxonly",
    }
)


def qwen25_ocr_structured_outputs(task: object, *, enabled: bool) -> dict | None:
    """Return the narrow vLLM JSON schema used by Qwen2.5-VL OCR repair.

    The schema is opt-in because structured decoding changes generation, not
    merely scoring.  It is restricted to the eight OCR task IDs and requires
    both ``bbox_2d`` and ``text`` so a text-only repetition cannot be accepted
    as a valid completion.
    """

    if not enabled or str(task) not in QWEN25_OCR_TASKS:
        return None
    coordinate = {"type": "integer", "minimum": 0}
    schema = {
        "type": "array",
            # Qwen2.5-VL can enter a syntactically valid object repetition
            # loop on dense OCR pages.  Bound the array so constrained
            # decoding must emit a closing bracket before the token budget is
            # exhausted.  128 is above the useful prediction cardinality for
            # this checkpoint while keeping pathological responses valid.
            "maxItems": 128,
        "items": {
            "type": "object",
            "properties": {
                "bbox_2d": {
                    "type": "array",
                    "items": coordinate,
                    "minItems": 4,
                    "maxItems": 4,
                },
                    "text": {"type": "string", "minLength": 1, "maxLength": 512},
            },
            "required": ["bbox_2d", "text"],
            "additionalProperties": False,
        },
    }
    return {
        "json": schema,
        "disable_fallback": True,
        "disable_additional_properties": True,
    }


def openai_stop_from_until(until: object) -> str | list[str] | None:
    """Translate lmms-eval ``until`` into the OpenAI ``stop`` contract.

    OpenAI-compatible chat APIs accept one string or at most four strings.
    Keeping this conversion explicit prevents ``generate_until`` requests from
    silently running to ``max_tokens`` when the model does not emit EOS.
    """

    if until is None:
        return None
    if isinstance(until, str):
        if not until:
            return None
        stripped = until.strip()
        if stripped.startswith(("[", "(")):
            try:
                parsed = ast.literal_eval(stripped)
            except (SyntaxError, ValueError) as exc:
                raise ValueError(
                    f"invalid serialized generation until: {until!r}"
                ) from exc
            return openai_stop_from_until(parsed)
        return until
    if not isinstance(until, Sequence) or isinstance(until, (bytes, bytearray)):
        raise TypeError("generation until must be a string or a sequence of strings")

    stops = list(until)
    if any(not isinstance(stop, str) for stop in stops):
        raise TypeError("every generation until entry must be a string")
    stops = [stop for stop in stops if stop]
    if len(stops) > 4:
        raise ValueError("OpenAI-compatible stop supports at most four sequences")
    return stops or None


def normalize_openai_system_content(
    messages: Sequence[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Make system messages compatible with strict OpenAI chat servers.

    ``ChatMessages`` represents every content field as an OpenAI multimodal
    list.  Swift's Qwen/Oxygen template accepts that form for user turns but
    requires system content to be a plain string.  Normalizing only system
    turns preserves all image-bearing user messages and fixes GUI tasks that
    otherwise kill the inference worker before the first token is generated.
    """

    normalized: list[dict[str, Any]] = []
    for original in messages:
        message = dict(original)
        content = message.get("content")
        if message.get("role") == "system" and isinstance(content, list):
            text_parts: list[str] = []
            for item in content:
                if not isinstance(item, dict):
                    raise TypeError("system content list entries must be objects")
                item_type = item.get("type")
                if item_type not in {"text", "input_text"}:
                    raise ValueError(
                        f"system content cannot contain multimodal item: {item_type!r}"
                    )
                text = item.get("text", "")
                if not isinstance(text, str):
                    raise TypeError("system text content must be a string")
                text_parts.append(text)
            message["content"] = "".join(text_parts)
        normalized.append(message)
    return normalized
