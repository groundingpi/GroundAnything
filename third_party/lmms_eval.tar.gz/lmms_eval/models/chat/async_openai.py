# Adapted from lmms-eval: https://github.com/EvolvingLMMs-Lab/lmms-eval
# Copyright (c) 2025 LMMs-Lab.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import ctypes
import fcntl
import gc
import hashlib
import base64
import json
import os
import shutil
import tempfile
import uuid
from io import BytesIO
from multiprocessing import cpu_count
from typing import List, Optional, Tuple, Union

import numpy as np
import requests as url_requests
from accelerate import Accelerator, DistributedType
from tqdm import tqdm

from lmms_eval.api.instance import Instance
from lmms_eval.api.model import lmms
from lmms_eval.api.registry import register_model

try:
    from decord import VideoReader, cpu
except ImportError:
    pass

from dotenv import find_dotenv, load_dotenv
from loguru import logger as eval_logger
from openai import AsyncOpenAI
from PIL import Image

from lmms_eval.api.model import lmms
from lmms_eval.models.simple.openai_compatible import (
    OpenAICompatible as OpenAICompatibleSimple,
)
from lmms_eval.models.chat.generation_contract import (
    normalize_openai_system_content,
    openai_stop_from_until,
    qwen25_ocr_structured_outputs,
)
from lmms_eval.protocol import ChatMessages

# Credentials/configuration are injected explicitly by the release launcher.


def _payload_trace_enabled():
    """Enable content-free diagnostics only when explicitly requested."""

    override = os.getenv("GAM_EVAL_VERBOSE_PAYLOAD")
    if override is not None:
        return override.strip().lower() in {"1", "true", "yes", "on"}
    return False


def _append_jsonl_atomic(audit_path, record, mode):
    """Append one complete JSONL record across concurrent evaluator processes."""

    parent = os.path.dirname(os.path.abspath(audit_path))
    os.makedirs(parent, exist_ok=True)
    line = (json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8")
    descriptor = os.open(audit_path, os.O_APPEND | os.O_CREAT | os.O_WRONLY, mode)
    try:
        os.fchmod(descriptor, mode)
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        view = memoryview(line)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise OSError("short JSONL audit write")
            view = view[written:]
    finally:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            os.close(descriptor)


def _append_request_audit(record):
    """Write numeric request diagnostics without messages, URLs or credentials."""

    audit_path = os.getenv("GAM_EVAL_REQUEST_AUDIT_PATH")
    if not audit_path:
        return
    safe = {"event": "openai_request"}
    for key in ("request_index", "max_tokens", "temperature", "top_p", "top_k", "repetition_penalty"):
        value = record.get(key)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            safe[key] = value
    _append_jsonl_atomic(audit_path, safe, 0o600)


def _append_response_audit(record):
    """Persist the complete provider response without credentials or image payloads.

    This is opt-in and intended for external-API evaluations where every raw
    completion must remain auditable.  The caller controls the destination via
    ``GAM_EVAL_RESPONSE_AUDIT_PATH``; authentication material is deliberately
    never included in the record.
    """

    audit_path = os.getenv("GAM_EVAL_RESPONSE_AUDIT_PATH")
    if not audit_path:
        return
    _append_jsonl_atomic(audit_path, record, 0o600)

def _bound_qwen37_inline_images(openai_messages):
    """Keep Qwen3.7 API data-URI images below the provider hard limit.

    The normal VLM path intentionally preserves the original PNG payload.  A
    separate ``qwen37_api`` family is used only for the external API whose
    gateway rejects a single data URI above 20 MiB.  We downsample/re-encode
    only oversized images; prompts, coordinates, and all other providers are
    untouched.
    """
    if os.getenv("GAM_EVAL_VLM_FAMILY") != "qwen37_api":
        return
    try:
        limit = int(os.getenv("GAM_EVAL_API_MAX_IMAGE_BYTES", str(15 * 1024 * 1024)))
    except ValueError:
        limit = 15 * 1024 * 1024
    limit = max(1 * 1024 * 1024, min(limit, 19 * 1024 * 1024))
    for message in openai_messages:
        for item in message.get("content", []) or []:
            if not isinstance(item, dict) or item.get("type") != "image_url":
                continue
            image_url = item.get("image_url")
            if not isinstance(image_url, dict):
                continue
            url = image_url.get("url")
            if not isinstance(url, str) or not url.startswith("data:image/"):
                continue
            try:
                header, encoded = url.split(",", 1)
                raw = base64.b64decode(encoded)
            except Exception:
                continue
            if len(url.encode("utf-8")) <= limit:
                continue
            try:
                image = Image.open(BytesIO(raw)).convert("RGB")
            except Exception:
                continue
            original_w, original_h = image.size
            # Try progressively smaller JPEGs.  The first successful option
            # keeps as much visual detail as possible while satisfying the
            # gateway limit including the data-URI header.
            for scale in (1.0, 0.85, 0.70, 0.55, 0.42, 0.32, 0.24, 0.18):
                width = max(256, int(original_w * scale))
                height = max(256, int(original_h * scale))
                candidate = image if scale == 1.0 else image.resize(
                    (width, height), Image.Resampling.LANCZOS
                )
                for quality in (88, 78, 68, 58, 48):
                    buffer = BytesIO()
                    candidate.save(buffer, format="JPEG", quality=quality, optimize=True)
                    candidate_encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
                    candidate_url = f"data:image/jpeg;base64,{candidate_encoded}"
                    if len(candidate_url.encode("utf-8")) <= limit:
                        image_url["url"] = candidate_url
                        break
                else:
                    continue
                break

@register_model("async_openai_compatible_chat")
class AsyncOpenAIChat(lmms):
    is_simple = False

    def __init__(
        self,
        model_version: str = "grok-2-latest",
        base_url: str = None,
        api_key: str = None,
        timeout: int = 600,
        max_retries: int = 5,
        max_size_in_mb: int = 20,
        mcp_server_path: str = None,
        num_cpus: int = None,
        work_dir: str = None,
        fps: Optional[int] = None,
        nframes: Optional[int] = 64,
        max_frames: Optional[int] = 768,
        max_pixels: Optional[int] = 151200,
        min_pixels: Optional[int] = 28 * 28,
        is_qwen3_vl: bool = False,
        enable_thinking: bool = True,
        **kwargs,
    ) -> None:
        super().__init__()
        self.model_version = model_version
        self.timeout = timeout
        self.max_retries = max_retries
        self.max_size_in_mb = max_size_in_mb  # some models have a limit on the size of the image
        if num_cpus is None:
            self.num_cpus = cpu_count() // 2
        else:
            self.num_cpus = num_cpus
        self.work_dir = work_dir if work_dir is not None else tempfile.mkdtemp()
        self.fps = fps
        self.nframes = nframes
        self.base_url = base_url if base_url is not None else os.getenv("OPENAI_API_BASE")
        self.api_key = api_key if api_key is not None else os.getenv("OPENAI_API_KEY")
        # Honour the evaluator-level retry contract for transient transport
        # failures.  Previously ``max_retries`` was stored on ``self`` but was
        # not passed to the SDK clients, so a single exhausted ReadError could
        # abort an otherwise complete long-running benchmark shard.
        self.client = AsyncOpenAI(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        # A single large eval task (for example VisualPrompt LVIS) otherwise
        # drives only one replica even when the launcher has one vLLM server per
        # GPU.  An explicit, launcher-owned URL list enables deterministic
        # request-level round-robin without changing prompts, decoding, or
        # metric aggregation.  Keep the historical single-client path as the
        # default when the variable is unset.
        replica_urls = [
            value.strip()
            for value in os.getenv("GAM_OPENAI_BASE_URLS", "").split(",")
            if value.strip()
        ]
        if replica_urls:
            self._replica_urls = replica_urls
            self._replica_clients = [
                AsyncOpenAI(
                    api_key=self.api_key,
                    base_url=url,
                    timeout=timeout,
                    max_retries=max_retries,
                )
                for url in replica_urls
            ]
        else:
            self._replica_urls = [self.base_url]
            self._replica_clients = [self.client]
        self._per_replica_concurrency = int(
            os.getenv("GAM_OPENAI_PER_REPLICA_CONCURRENCY", "0")
        )
        if self._per_replica_concurrency < 0:
            raise ValueError("GAM_OPENAI_PER_REPLICA_CONCURRENCY must be non-negative")
        self.max_pixels = max_pixels
        self.min_pixels = min_pixels
        self.max_frames = max_frames
        self.is_qwen3_vl = is_qwen3_vl
        self.enable_thinking = enable_thinking
        if mcp_server_path is not None:
            from lmms_eval.mcp import MCPClient
            self.mcp_client = MCPClient(mcp_server_path)
            os.makedirs(self.work_dir, exist_ok=True)
        else:
            self.mcp_client = None

        accelerator = Accelerator()
        # assert self.batch_size_per_gpu == 1, "Llava currently does not support batched generation. See https://github.com/haotian-liu/LLaVA/issues/754. HF Llava also has this issue."
        if accelerator.num_processes > 1:
            assert accelerator.distributed_type in [DistributedType.FSDP, DistributedType.MULTI_GPU, DistributedType.DEEPSPEED], "Unsupported distributed type provided. Only DDP and FSDP are supported."
            self.accelerator = accelerator
            if self.accelerator.is_local_main_process:
                eval_logger.info(f"Using {accelerator.num_processes} devices with data parallelism")
            self._rank = self.accelerator.local_process_index
            self._world_size = self.accelerator.num_processes
        else:
            self.accelerator = accelerator
            self._rank = self.accelerator.local_process_index
            self._world_size = self.accelerator.num_processes

        self.device = self.accelerator.device

    @property
    def model(self):
        # returns the model, unwrapping it if using Accelerate
        return self.client

    @property
    def batch_size(self):
        return self.batch_size_per_gpu

    @property
    def rank(self):
        return self._rank

    @property
    def world_size(self):
        return self._world_size

    def loglikelihood(self, requests: List[Instance]) -> List[Tuple[float, bool]]:
        assert False, "TODO, not implemented"

    def generate_until_multi_round(self, requests) -> List[str]:
        raise NotImplementedError("TODO: Implement multi-round generation for LLaVAHF")

    def _replica_index(self, task: str, idx: int) -> int:
        """Route concurrent tasks to replicas without lock-step hot spots.

        Every evaluation task runs in an independent evaluator process.  Starting
        each process at replica zero makes their first concurrent windows land
        on the same small subset of servers, even when dozens of replicas are
        available.  A stable per-task phase offset preserves deterministic
        round-robin ordering while spreading independent tasks across replicas.
        """
        if len(self._replica_clients) == 1:
            return 0
        digest = hashlib.blake2b(task.encode("utf-8"), digest_size=8).digest()
        offset = int.from_bytes(digest, "big") % len(self._replica_clients)
        return (offset + idx) % len(self._replica_clients)

    async def maybe_forward_with_tool(self, request: Instance, idx: int):
        """
        Forward the request to the OpenAI API, using tools if available.
        This method is designed to handle chat messages and tool calls in an asynchronous manner.
        It retrieves the chat messages from the request, prepares the payload, and sends it to the OpenAI API.
        If the response indicates that tool calls are needed, it will call the tools using the MCP client and continue the conversation until a final response is received.
        :param request: The request instance containing the chat messages and other parameters.
        :param idx: The index of the request in the batch. (Use to restore the original order of responses)
        """
        ctx, doc_to_messages, gen_kwargs, doc_id, task, split = request.args
        chat_messages = doc_to_messages(self.task_dict[task][split][doc_id])
        chat_messages: ChatMessages = ChatMessages(**{"messages": chat_messages})
        
        video_kwargs = {"max_pixels": self.max_pixels, "min_pixels": self.min_pixels}
        if self.fps is not None:
            video_kwargs["fps"] = self.fps
        else:
            video_kwargs["nframes"] = self.nframes
        if self.max_frames is not None:
            video_kwargs["max_frames"] = self.max_frames
        if self.is_qwen3_vl:
            messages = chat_messages.to_qwen3_vl_openai_messages(video_kwargs)
        else:
            messages = chat_messages.to_openai_messages(video_kwargs)
        messages = normalize_openai_system_content(messages)
        _bound_qwen37_inline_images(messages)
        images, videos, audios = chat_messages.extract_media()
        # Some model-family evaluation branches must be strictly tool-free.
        # Keep this opt-in so the historical MCP-enabled behavior is unchanged
        # for every other evaluator.  The switch suppresses both tool schema
        # exposure and the follow-up tool execution loop.
        disable_tools = os.getenv("GAM_EVAL_DISABLE_TOOLS", "0") == "1"
        if self.mcp_client is not None and not disable_tools:
            for image_idx, image in enumerate(images):
                image_path = os.path.join(self.work_dir, f"{uuid.uuid4()}.jpg")
                image.save(image_path)
                messages[-1]["content"].append({"type": "text", "text": f"\nImage {image_idx} has image path: {image_path}"})
            for video_idx, video in enumerate(videos):
                messages[-1]["content"].append({"type": "text", "text": f"\nVideo {video_idx} has video path: {video}"})

        # payload = {"messages": messages}
        # payload["model"] = self.model_version
        # all_response = ""

        # if "max_new_tokens" not in gen_kwargs:
        #     gen_kwargs["max_new_tokens"] = 1024
        # if "temperature" not in gen_kwargs:
        #     gen_kwargs["temperature"] = 0
        # if "top_p" not in gen_kwargs:
        #     gen_kwargs["top_p"] = None
        # if "do_sample" not in gen_kwargs:
        #     gen_kwargs["do_sample"] = False
        # # payload["max_completion_tokens"] = gen_kwargs["max_new_tokens"]
        # payload["max_tokens"] = gen_kwargs["max_new_tokens"]
        # payload["temperature"] = gen_kwargs["temperature"]
        payload = {"messages": messages}
        payload["model"] = self.model_version
        all_response = ""

        # lmms-eval expresses generate-until termination through ``until``.
        # The OpenAI-compatible API names the same contract ``stop``.  The
        # previous adapter dropped it, so generations without EOS could run to
        # max_tokens (16k for detection tasks).
        # Thinking checkpoints put blank lines inside <think>...</think>.
        # Their task-level ``until=['\\n\\n']`` would truncate reasoning before
        # the final structured answer.  Keep this launcher-scoped and opt-in so
        # all other models retain the normal OpenAI stop contract.
        disable_until_stop = os.getenv("GAM_EVAL_DISABLE_UNTIL_STOP", "0") == "1"
        stop = None if disable_until_stop else openai_stop_from_until(gen_kwargs.get("until"))
        if stop is not None:
            payload["stop"] = stop
        
        # top_p=gen_kwargs.get("top_p", 0.8)
        # top_k=gen_kwargs.get("top_k", 20)
        # temperature=gen_kwargs.get("temperature", 0.7)
        # repetition_penalty=gen_kwargs.get("repetition_penalty", 1.0)
        # presence_penalty=gen_kwargs.get("presence_penalty", 1.5)
        # max_tokens=gen_kwargs.get("max_tokens", 16000)
        # seed=gen_kwargs.get("seed", 3408)
        
        eval_args = {}
        for arg in [
            "top_p",
            "top_k",
            "temperature",
            "repetition_penalty",
            "presence_penalty",
            "max_tokens",
            "min_tokens",
            "seed",
            "skip_special_tokens",
            "spaces_between_special_tokens",
            "generation_mode",
            # SGLang-specific, inert unless a DLM-only task profile requests
            # it.  Keeping the matched structural stop is required by GAM's
            # native special-token parser; existing VLM configs do not set it.
            "no_stop_trim",
        ]:
            if arg in gen_kwargs:
                eval_args[arg] = gen_kwargs[arg]

        # lmms-eval's generation CLI supports only scalar comma-delimited
        # values. DLM Referring therefore passes five audited scalar fields;
        # assemble them here into SGLang's request-scoped custom_params. No
        # VLM/GAM task profile defines these keys, so their behavior is inert.
        dlm_contract_fields = {
            "gam_dlm_coordinate_limit": "coordinate_limit",
            "gam_dlm_box_start_token_id": "box_start_token_id",
            "gam_dlm_box_end_token_id": "box_end_token_id",
            "gam_dlm_coord_token_min_id": "coord_token_min_id",
            "gam_dlm_coord_token_max_id": "coord_token_max_id",
        }
        custom_params = {}
        present = [key for key in dlm_contract_fields if key in gen_kwargs]
        if present:
            if len(present) != len(dlm_contract_fields):
                raise ValueError(
                    "incomplete DLM single-target generation contract"
                )
            custom_params["gam_dlm_single_target"] = {
                target: int(gen_kwargs[source])
                for source, target in dlm_contract_fields.items()
            }
            custom_params["gam_dlm_single_target"]["expected_cardinality"] = int(
                gen_kwargs.get("gam_dlm_expected_cardinality", 1)
            )

        # The new block decoder has its own reliability/sampling contract.
        # Import and pack it only when DLM-only scalar fields are present, so
        # the canonical VLM/GAM request path remains byte-for-byte unchanged.
        if any(key.startswith("gam_dlm_decode_") for key in gen_kwargs):
            from infer.decode.request_contract import pack_decode_custom_params

            decode_params = pack_decode_custom_params(gen_kwargs)
            if decode_params:
                custom_params["gam_dlm_decode"] = decode_params
        if custom_params:
            eval_args["custom_params"] = custom_params
        
        if _payload_trace_enabled():
            eval_logger.debug("Generation parameters prepared; values omitted.")
        if not self.enable_thinking:
            eval_args['chat_template_kwargs'] = {'enable_thinking': False}
        structured_outputs = qwen25_ocr_structured_outputs(
            task,
            enabled=os.getenv("GAM_EVAL_QWEN25_OCR_STRUCTURED", "0") == "1",
        )
        if structured_outputs is not None:
            eval_args["structured_outputs"] = structured_outputs
        # Some generic VLM tasks intentionally end with an assistant prefill
        # (for example GUI's ``coordinate: [`` contract).  DeepSeek's chat
        # template otherwise treats that prefix as completed history and opens
        # a new ``### Response:``, producing repeated/incomplete tool calls.
        # Keep the prompt/messages unchanged and ask vLLM to continue the final
        # assistant message exactly as intended.
        if (
            os.getenv("GAM_EVAL_CONTINUE_FINAL_MESSAGE", "0") == "1"
            and messages
            and messages[-1].get("role") == "assistant"
        ):
            eval_args["continue_final_message"] = True
            eval_args["add_generation_prompt"] = False
        payload['extra_body']=eval_args

        replica_index = self._replica_index(task, idx)
        request_client = self._replica_clients[replica_index]
        request_base_url = self._replica_urls[replica_index]

        _append_request_audit(
            {
                "event": "openai_request",
                "task": task,
                "split": split,
                "doc_id": doc_id,
                "request_index": idx,
                "eval_mode": os.getenv("GAM_EVAL_MODE"),
                "model": self.model_version,
                "base_url": request_base_url,
                "max_tokens": eval_args.get("max_tokens"),
                "temperature": eval_args.get("temperature"),
                "top_p": eval_args.get("top_p"),
                "top_k": eval_args.get("top_k"),
                "repetition_penalty": eval_args.get("repetition_penalty"),
                "generation_mode": eval_args.get("generation_mode"),
                "no_stop_trim": eval_args.get("no_stop_trim"),
                "custom_params": eval_args.get("custom_params"),
                "structured_outputs": eval_args.get("structured_outputs"),
                "stop": payload.get("stop"),
                "extra_body": eval_args,
            }
        )
        
        if _payload_trace_enabled():
            eval_logger.debug("Request prepared; content omitted.")

        if self.mcp_client is not None and not disable_tools:
            # get the function list from the MCP server
            functions = await self.mcp_client.get_function_list()
            payload["tools"] = functions
            payload["tool_choice"] = "auto"  # or "auto" for automatic tool selection

        response = await request_client.chat.completions.create(**payload)
        try:
            response_payload = response.model_dump(mode="json")
        except TypeError:
            response_payload = response.model_dump()
        except Exception:
            response_payload = {"repr": repr(response)}
        _append_response_audit(
            {
                "event": "openai_response",
                "task": task,
                "split": split,
                "doc_id": doc_id,
                "request_index": idx,
                "eval_mode": os.getenv("GAM_EVAL_MODE"),
                "model": self.model_version,
                "response": response_payload,
            }
        )
        if not getattr(response, "choices", None):
            raise RuntimeError("OpenAI-compatible server returned no completion choices")
        message = response.choices[0].message
        finish_reason = response.choices[0].finish_reason
        refusal = getattr(message, "refusal", None)
        if finish_reason == "content_filter" or refusal == "data_inspection_failed":
            # Preserve an unambiguous in-cache marker.  The evaluator excludes
            # this provider-side abstention from metric aggregation while still
            # logging the sample and full audited response for accountability.
            last_response = "__GAM_PROVIDER_POLICY_FILTERED__"
        else:
            last_response = message.content
        # Sometimes asyncio return None, skip this case
        try:
            all_response += last_response
        except Exception as e:
            all_response += f"Error: {str(e)}"

        while not disable_tools and response.choices[0].finish_reason == "tool_calls":
            messages.append({"role": "assistant", "content": last_response})
            messages.append({"role": "assistant", "tool_calls": response.choices[0].message.tool_calls})
            message = response.choices[0].message
            tool_messages = []
            if message.tool_calls:
                eval_logger.debug("Calling tool with MCP client")
                for call in message.tool_calls:
                    eval_logger.debug(f"Calling {call.function.name}...")
                    result = await self.mcp_client.run_tool(call.function.name, eval(call.function.arguments))
                    all_response += f"<tool_call>{call.function.name} {call.function.arguments}</tool_call></tool_response>"
                    tool_messages.append({"role": "tool", "name": call.function.name, "content": []})
                    for content in result.content:
                        tool_message = self.mcp_client.convert_result_to_openai_format(content)
                        for content in tool_message:
                            if content["type"] == "image_url":
                                all_response += "<image_url>"
                            elif content["type"] == "text":
                                all_response += content["text"]
                        tool_messages[-1]["content"].extend(tool_message)
                    all_response += "</tool_response>"

            response = await request_client.chat.completions.create(
                model=self.model_version,
                messages=messages + tool_messages,
                max_tokens=gen_kwargs["max_new_tokens"],
                temperature=gen_kwargs["temperature"],
                tools=functions,
                tool_choice="auto",
            )
            last_response = response.choices[0].message.content
            try:
                all_response += last_response
            except Exception as e:
                all_response += str(e)
        self.add_request_response_to_cache(request, all_response)
        return all_response, idx

    def generate_until(self, requests) -> List[str]:
        self.load_cache()
        # Preserve original request order across a partially cached restart.
        # The upstream lmms helper concatenates cached responses before fresh
        # responses, which associates predictions with the wrong doc whenever
        # only part of a task is cached.  Keep an indexed result vector here.
        original_requests = list(requests)
        results = [None] * len(original_requests)
        pending = []
        for original_index, request in enumerate(original_requests):
            cached = self.cache_dict[request.task_name].get(request.doc_id)
            if cached is None:
                pending.append((original_index, request))
                continue
            # In-memory appends use the complete cache record; a fresh process
            # loads the response string directly from JSONL.
            if isinstance(cached, dict) and "response" in cached:
                cached = cached["response"]
            results[original_index] = cached
        eval_logger.info(f"Loaded {len(original_requests) - len(pending)} responses from cache")
        eval_logger.info(f"Not cached {len(pending)} requests")

        async def run():
            res = []
            pbar = tqdm(total=len(pending), disable=(self.rank != 0), desc="Model Responding")
            sem = asyncio.Semaphore(self.num_cpus)
            request_window_raw = os.getenv("GAM_EVAL_ASYNC_REQUEST_WINDOW", "0")
            try:
                request_window = int(request_window_raw)
            except ValueError as exc:
                raise ValueError("GAM_EVAL_ASYNC_REQUEST_WINDOW must be an integer") from exc
            if request_window < 0:
                raise ValueError("GAM_EVAL_ASYNC_REQUEST_WINDOW must be non-negative")
            if request_window == 0:
                request_window = max(1, len(pending))
            replica_sems = (
                [
                    asyncio.Semaphore(self._per_replica_concurrency)
                    for _ in self._replica_clients
                ]
                if self._per_replica_concurrency
                else []
            )

            async def _process(req, idx):
                async with sem:
                    if replica_sems:
                        task = req.args[4]
                        replica_index = self._replica_index(task, idx)
                        async with replica_sems[replica_index]:
                            return await self.maybe_forward_with_tool(req, idx)
                    return await self.maybe_forward_with_tool(req, idx)

            # Bound coroutine residency for 20K-image API benches. Creating one
            # Task per request up front retained enough multimodal state for the
            # host OOM killer to terminate otherwise healthy remote inference.
            for window_start in range(0, len(pending), request_window):
                window = pending[window_start : window_start + request_window]
                tasks = [
                    asyncio.create_task(_process(req, original_index))
                    for original_index, req in window
                ]
                for task in asyncio.as_completed(tasks):
                    content, idx = await task
                    res.append((content, idx))
                    pbar.update(1)
                del tasks, window
                gc.collect()
                # PIL/Arrow frequently release large image buffers to glibc
                # arenas rather than the OS.  Long remote-API tasks can then be
                # OOM-killed even though Python no longer references them.
                # malloc_trim is scheduling/runtime hygiene only; responses and
                # request ordering are unchanged.
                try:
                    ctypes.CDLL(None).malloc_trim(0)
                except (AttributeError, OSError):
                    pass

            pbar.close()
            return res

        eval_results = asyncio.run(run())
        for content, original_index in eval_results:
            results[original_index] = content
        if any(value is None for value in results):
            raise RuntimeError("async API evaluation left an unresolved response slot")
        if self.mcp_client is not None:
            shutil.rmtree(self.work_dir)
        return list(results)
