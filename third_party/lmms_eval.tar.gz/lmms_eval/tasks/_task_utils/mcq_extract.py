"""Deterministic multiple-choice answer extraction used by General evals."""

import re
from typing import List, Optional


_DEFAULT_CHOICES = ["A", "B", "C", "D", "E", "F", "G", "H"]
_ANSWER_PHRASES = [
    "the answer is",
    "answer is",
    "the correct answer is",
    "correct answer is",
    "the best answer is",
    "best answer is",
    "the correct option is",
    "correct option is",
    "the best option is",
    "best option is",
    "the choice is",
    "choice is",
    "the correct choice is",
    "correct choice is",
    "i choose",
    "i select",
    "i pick",
    "my answer is",
    "my choice is",
    "옵션",
    "정답은",
    "답은",
    "답:",
    "答案是",
    "答案为",
    "选",
    "答えは",
]
_FORMAT_PRIORITY = {
    "start": 10,
    "end": 9,
    "phrase": 7,
    "parentheses": 6,
    "period": 5,
    "colon": 4,
    "right_paren": 3,
    "space": 2,
    "fallback": 0,
}


def extract_mcq_answer(
    response: str, choices: Optional[List[str]] = None
) -> str:
    """Extract the most likely final choice letter from free-form output."""

    if not response or not response.strip():
        return ""
    all_choices = choices or _DEFAULT_CHOICES
    text = response.strip()
    for char in [",", ".", "!", "?", ";", ":", "'", '"']:
        text = text.strip(char)
    text = " " + text + " "
    candidates = []

    formats = (
        ("parentheses", lambda choice: f"({choice})"),
        ("period", lambda choice: f"{choice}."),
        ("colon", lambda choice: f"{choice}:"),
        ("right_paren", lambda choice: f"{choice})"),
        ("space", lambda choice: f"{choice} "),
    )
    for format_name, formatter in formats:
        for choice in all_choices:
            marker = formatter(choice)
            if marker in text:
                candidates.append((choice, text.rfind(marker), format_name))

    text_lower = text.lower()
    for phrase in _ANSWER_PHRASES:
        index = text_lower.find(phrase)
        if index == -1:
            continue
        after = index + len(phrase)
        for choice in all_choices:
            choice_position = text.find(choice, after)
            if choice_position != -1:
                candidates.append((choice, choice_position, "phrase"))

    stripped = text.strip()
    for choice in all_choices:
        if stripped.startswith(choice) and (
            len(stripped) == 1 or not stripped[1].isalpha()
        ):
            candidates.append((choice, 0, "start"))
        if stripped.endswith(choice) and (
            len(stripped) == 1 or not stripped[-2].isalpha()
        ):
            candidates.append((choice, len(text) - 1, "end"))

    if not candidates:
        for choice in all_choices:
            if re.search(rf"(?<![A-Za-z]){re.escape(choice)}(?![A-Za-z])", text):
                candidates.append((choice, text.rfind(choice), "fallback"))
    if not candidates:
        return ""
    candidates.sort(
        key=lambda item: (_FORMAT_PRIORITY.get(item[2], 0), item[1]),
        reverse=True,
    )
    return candidates[0][0]
