import ast
import json
import os
import re
from loguru import logger as eval_logger
from lmms_eval.llm_judge import ServerConfig, get_server

API_TYPE = os.getenv("API_TYPE", "openai")
MODEL_VERSION = os.getenv("MODEL_VERSION", "gpt-4o-2024-11-20")

# Initialize the judge server
server_config = ServerConfig(
    model_name=MODEL_VERSION,
)
server = get_server(server_name=API_TYPE, config=server_config)

def parse_options(options):
    option_letters = [chr(ord("A") + i) for i in range(len(options))]
    choices_str = "\n".join([f"{option_letter}. {option}" for option_letter, option in zip(option_letters, options)])
    return choices_str

# def construct_prompt(doc, mc_prompt="", open_ended_prompt="", prompt_type="reasoning"):
#     question = doc["question"]
#     if doc["question_type"] == "multiple-choice":
#         # Weirdly, data["options"] is a string in MMMU Huggingface dataset
#         parsed_options = parse_options(ast.literal_eval(doc["options"]))
#         # parsed_options already prepends a newline so no need to add space here
#         question = f"{question}\n{parsed_options}\n\n{mc_prompt}"
#     else:
#         question = f"{question}\n\n{open_ended_prompt}"

#     return question
def construct_prompt(doc, post_prompt="Answer with the option letter from the given choices directly."):
    
    if "question" in doc:
        question = doc["question"]
    else:
        question="Answer the question based on the picture"
    # Weirdly, data["options"] is a string in MMMU Huggingface dataset
    parsed_options = parse_options(ast.literal_eval(doc["options"]))
    # parsed_options already prepends a newline so no need to add space here
    question = f"{question}\n{parsed_options}\n\n{post_prompt}"
    return question


def llm_as_judge_eval(doc, results):
    parsed_preds = []
    scores = []
    #print("doc::::",doc)
    for pred in results:
        formatted_question = construct_prompt(doc)
        # Extract content from <answer> tags if present, handling potential spaces
        answer = doc["answer"]
        if isinstance(pred, str):
            match = re.search(r"<answer>\s*([\s\S]*?)\s*</answer>", pred)
            if match:
                pred = match.group(1).strip()
        try:
            # Use the llm_judge API for binary evaluation
            result = server.evaluate_binary(question=formatted_question, answer=str(answer), prediction=pred, output_format="0/1")

            # Parse the result
            if result["success"]:
                judge_response = result["result"]
                judge_score = int(judge_response) if type(judge_response) == str else judge_response
            else:
                eval_logger.error(f"Judge evaluation failed: {result.get('raw_response', 'Unknown error')}")
                judge_score = 0

        except Exception as e:
            eval_logger.error(f"Error getting judge response: {e}")
            judge_score = 0

        scores.append(judge_score)
        parsed_preds.append(pred)

    # Calculate the average score for this document
    avg_score = sum(1 if score == 1 else 0 for score in scores) / len(scores) if scores else 0
    return {"llm_as_judge_eval": avg_score}

def llm_as_judge_eval_single(answer, pred):
    try:
        # Use the llm_judge API for binary evaluation
        result = server.evaluate_binary(question="", answer=str(answer), prediction=str(pred), output_format="0/1")

        # Parse the result
        if result["success"]:
            judge_response = result["result"]
            judge_score = int(judge_response) if type(judge_response) == str else judge_response
        else:
            eval_logger.error(f"Judge evaluation failed: {result.get('raw_response', 'Unknown error')}")
            judge_score = 0

    except Exception as e:
        eval_logger.error(f"Error getting judge response: {e}")
        judge_score = 0
        
    if judge_score==1:
        judge_flag=True
    else:
        judge_flag=False
    
    return judge_flag