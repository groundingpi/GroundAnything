"""Resolve explicitly configured dataset locations for external tasks."""
from eval.utils.eval_data_root import expand_data_paths

def expand_gam_eval_data_root(value):
    return expand_data_paths(value)
