# Spatial Evaluation Engine

This package adapts lmms-eval 0.5.0 for the parent project's HTTP evaluation workflow. It includes the evaluation engine, OpenAI-compatible clients, and shared task helpers. Task definitions are provided by the parent project's `eval/` directory through `--include_path eval`.

Use the parent project's evaluation environment and launch commands. Dataset locations and service settings are supplied by the parent project's configuration files; API credentials are supplied explicitly or through environment variables.

The upstream project is [lmms-eval](https://github.com/EvolvingLMMs-Lab/lmms-eval). See `NOTICE.release` for source provenance and adaptations, and the parent project's `third_party/manifest.json` for file hashes.

The bundled `LICENSE` distinguishes the MIT-licensed evaluation pipeline from the Apache-2.0-licensed multimodal model and task additions. Original copyright and license notices are retained.

## Third-party attribution for anonymous review

Names of upstream authors, companies and institutions, contact addresses,
repository namespaces, public model/dataset identifiers and example URLs in
third-party source and license notices identify their original sources. They
are retained for attribution and interoperability, not as a declaration of
this submission's authorship or affiliation. Such attribution alone does not
disclose submission authors. Original licenses and copyright notices remain
unchanged. Local adaptations are recorded separately; an unverified local
remark is not assigned to upstream merely because it is in a dependency.
