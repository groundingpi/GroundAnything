# Transformers Dependency Snapshot

This directory contains the Transformers 5.7.0 runtime and build sources used by the parent project. The upstream project is [Hugging Face Transformers](https://github.com/huggingface/transformers).

Use the parent project's environment setup commands to install this snapshot with its matching dependencies. Source provenance and recorded distribution changes are listed in `NOTICE.release`; the parent project's `third_party/manifest.json` records file hashes.

The original `LICENSE` and file-level copyright and license notices are retained.

## Third-party attribution for anonymous review

Names of upstream authors, companies and institutions, contact addresses,
repository namespaces, public model/dataset identifiers and example URLs in
third-party source and license notices identify their original sources. They
are retained for attribution and interoperability, not as a declaration of
this submission's authorship or affiliation. Such attribution alone does not
disclose submission authors. Original licenses and copyright notices remain
unchanged. Local adaptations are recorded separately; an unverified local
remark is not assigned to upstream merely because it is in a dependency.
